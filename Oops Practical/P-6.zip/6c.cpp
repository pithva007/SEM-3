//Write a program to define a class 'Point' and implement a copy constructor to initialize one object with another. 

#include<bits/stdc++.h>
using namespace std;

class Point{
public:
    int a;
    int b;
    int c;
    Point(int a,int b,int c){
        this->c=c;
        this->a=a;
        this->b=b;
    }
    void display(){
        cout<<"a:"<<a<<" ";
        cout<<"b:"<<b<<" ";
        cout<<"c:"<<c<<" ";
        cout<<endl<<endl;
    }
};

int main(){
    Point p1(10,45,67);
    p1.display();
    Point p2=p1;  //Deep Copy
    p2.display();
    p2.b=99;
    p2.display();
    Point p3(p1);   //Deep Copy
    p3.c=0;
    p3.display();

    return 0;
}