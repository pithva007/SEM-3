//Develop a class 'Box' that uses a parameterized constructor to initialize length, breadth, and height, and display volume.

#include<bits/stdc++.h>
using namespace std;

class Box{
    int height;
    int width;
    int bredth;
public:
    void vol();

    Box(int height,int width,int bredth){
        this->bredth=bredth;
        this->height=height;
        this->width=width;
    }
};

void Box::vol(){
    cout<<"Volume is:"<<height*width*bredth;
}

int main(){
    Box b(25,33,56);
    b.vol();
    return 0;
}
