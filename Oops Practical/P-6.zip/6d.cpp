//Create a class with a static variable to count how many objects were created using the constructor.

#include<bits/stdc++.h>
using namespace std;

class Counter{
    static int count;
public:
    Counter(){
        count++;
    }
    void showCount(){
        cout<<count<<endl;
    }
};
int Counter:: count=0;

int main(){
    Counter c1,c2,c4,c7;
    c2.showCount();


    return 0;
}