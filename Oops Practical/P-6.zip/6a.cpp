//Create a class 'Counter' with a default constructor initializing count to zero, then increment and display the count. 

#include<bits/stdc++.h>
using namespace std;

class Counter{
    int count;
public:
    void incr(){
        count++;
    }
    void display(){
        cout<<"COUNT IS:"<<count;
    }
    Counter(){
        count=0;
    }
};

int main(){
    Counter c1;
    c1.incr();
    c1.incr();
    c1.incr();
    c1.incr();
    c1.display();

    return 0;
}
